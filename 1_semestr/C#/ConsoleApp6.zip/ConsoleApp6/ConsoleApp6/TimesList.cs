﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace ConsoleApp6
{
    [Serializable]
    class TimesList
    {

        private List<TimeItem> list;
        public TimesList(string filename)
        {
            filename += ".txt";
            if (File.Exists(filename))
            {
                Console.WriteLine("Файл существует!");
                Load(filename);
            }
            else
            {
                list = new List<TimeItem>();
                Console.WriteLine("Файл создан!");
            }
        }

        public void Add(TimeItem ti)
        {
            list.Add(ti);
        }
        public void Save(string filename)
        {
            try
            {
                filename += ".txt";
                BinaryFormatter t = new BinaryFormatter();
                FileStream fn = new FileStream(filename, FileMode.Create);
                t.Serialize(fn, list);
                fn.Close();
            }
            catch
            {
                Console.WriteLine("Ошибка сохранения!");
            }
        }
        public void Load(string filename)
        {
            try
            {
                BinaryFormatter t = new BinaryFormatter();
                FileStream fn = new FileStream(filename, FileMode.Open);
                list = (List<TimeItem>)t.Deserialize(fn);
                fn.Close();

                Console.WriteLine(ToString());

            }
            catch
            {
                Console.WriteLine("Ошибка загрузки");
            }
        }
        public override string ToString()
        {
            string str = "\n";

            foreach (TimeItem ti in list)
            {

                str += ti.ToString();
            }
            return str;
        }
    }
}
