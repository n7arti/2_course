﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp6
{
    public struct TimeItem
    {
        public int n;
        public int repeat;
        public double timeCPlus;
        public long timeCSharp;
        public long rat;
    }
    class Matrix
    {
        public int size;
        public double[] column;
        public double[] line;
        public Matrix(int n)
        {
            size = n;
            column = new double[size];
            line = new double[size];
            for (int i = 1; i < size; i++)
            {
                column[i] = size - 1 + i;
                line[i] =  i;
            }
            column[0] = 0;
            line[0] = 0;
        }
        public Matrix()
        {
            Console.WriteLine("Введите размер матрицы: ");
            size = Convert.ToInt32(Console.ReadLine());
            column = new double[size];
            line = new double[size];
            Console.WriteLine("Введите 1 элемент: ");
            column[0] = Convert.ToInt32(Console.ReadLine());
            line[0] = column[0];
            for (int i = 1; i < size; i++)
            {
                Console.WriteLine("Введите " + (i+1) + " элемент в строке: ");
                line[i] = Convert.ToInt32(Console.ReadLine()); 
            }
            for (int i = 1; i < size; i++)
            {
                Console.WriteLine("Введите " + (i + 1) + " элемент в столбце: ");
                column[i] = Convert.ToInt32(Console.ReadLine()); 
            }
        }
        public override string ToString()
        {
            double[,] matrix;
            matrix = new double[size, size];
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    if (i == j)
                        matrix[i, j] = line[0];
                    if (i > j)
                        matrix[i, j] = column[i - j];
                    if (j > i)
                        matrix[i, j] = line[j - i];
                }
            }
            string str = "";
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    str += matrix[i, j] + " ";
                }
                str += "\n";
            }
            return str;
        }
    }
}
