﻿using System;

namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(".................. 3..................");
            Console.Write("Введите название файла: ");
            string filename = Console.ReadLine();
            TimesList TL = new TimesList(filename);

            Console.WriteLine(".................. 4-6..................");
            string ans = "a";
            while(ans!="yes")
            {
                TimeItem TI = new TimeItem();
                Console.Write("Введите порядок матрицы: ");
                int n = Convert.ToInt32(Console.ReadLine());
                Console.Write("Введите количество повторов: ");
                int repeat = Convert.ToInt32(Console.ReadLine());
                //5
                Console.Write("Для завершения работы введите yes: ");
                ans = Console.ReadLine();
            }
            TL.Save(filename);
            Console.WriteLine(TL.ToString());
        }
    }
}
