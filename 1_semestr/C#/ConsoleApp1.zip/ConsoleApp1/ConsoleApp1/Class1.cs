﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    enum TimeFrame { Year, TwoYears, Long}; 
}
