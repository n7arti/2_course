﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class Person
    {
        private string name;
        private string surname;
        private DateTime birthday;

        public Person(string name_value, string surname_value, DateTime birthday_value)
        {
            name = name_value;
            surname = surname_value;
            birthday = birthday_value;
        }

        public Person()
        {
            name = "Ivan";
            surname = "Ivanov";
            birthday = new DateTime(2000, 1, 1);
        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public string Surname
        {
            get
            {
                return surname;
            }
            set
            {
                surname = value;
            }
        }

        public DateTime Birthday
        {
            get
            {
                return birthday;
            }
            set
            {
                birthday = new DateTime(birthday.Year, birthday.Month, birthday.Day);
            }
        }
         public int ChangeYear
        {
            get
            {
                return birthday.Year;
            }
            set
            {
                birthday = new DateTime(value, birthday.Month, birthday.Day);
            }
        }

        public override string ToString()
        {
            return name + " " + surname + " " + birthday.ToString("d");
        }
        public virtual string ToShortString()
        {
            return name + " " + surname;
        }
    }
}
