﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace ConsoleApp1
{
    class ResearchTeam
    {
        private string topic;//закрытые поля
        private string organization;
        private int number;
        private TimeFrame time;
        private Paper[] list;
        public ResearchTeam(string topic_value, string organization_value, int number_value, TimeFrame time_value)//конструктор с параметрами
        {
            topic = topic_value;
            organization = organization_value;
            number = number_value;
            time = time_value;
            //list = new Paper[0];
        }
        public ResearchTeam() //конструктор без параметров
        {
            topic = "Tema";
            organization = "OAO Apelsin";
            number = 66666666;
            time = TimeFrame.Year;
            list = new Paper[0];
        }
        public string Topic//свойства с методами get и set
        {
            get
            {
                return topic;
            }
            set
            {
                topic = value;
            }
        }
        public string Organization
        {
            get
            {
                return organization;
            }
            set
            {
                organization = value;
            }
        }
        public int Number
        {
            get
            {
                return number;
            }
            set
            {
                number = value;
            }
        }
        public TimeFrame Time
        {
            get
            {
                return time;
            }
            set
            {
                time = value;
            }
        }
        public Paper[] List
        {
            get
            {
                return list;
            }
            set
            {
                list = value;
            }
        }
        public Paper ReturnPublic//свойство типа Paper ( только с методом get), которое возвращает ссылку на публикацию с самой поздней датой выхода
        {
            get
            {
                int link = 0;
                if (list.Length == 0)
                    return null;
                else
                {
                    DateTime datemin = DateTime.MinValue;
                    for (int i = 0; i < list.Length; i++)
                    {
                        if (list[i].date > datemin)
                        {
                            datemin = list[i].date;
                            link = i;
                        }
                    }

                    return list[link];

                }
            }
        }
        public bool this[TimeFrame time_value]//индексатор булевского типа 
        {
            get
            {
                return Time == time_value;
            }
        }
        public void AddPaper(params Paper[] NewPaper)//метод добавления элементов в список публикаций
        {
            int NewSize = list.Length + NewPaper.Length;
            int Size = list.Length;

            Array.Resize(ref list, NewSize);
            Array.Copy(NewPaper, 0, list, Size, NewPaper.Length);
        }
        public override string ToString()//перегруженная версия виртуального метода string ToString()
        {
            string line = topic + " " + organization + " " + number.ToString() + " " + time.ToString() + "\n";
            for (int i = 0; i < list.Length; i++)
                line += list[i].ToString() + "\n"; 
            return line;
        }
        public virtual string ToShortString()//виртуальный метод string ToShortString()
        {
            return topic + " " + organization + " " + number.ToString() + " " + time.ToString();
        }
    }
}
