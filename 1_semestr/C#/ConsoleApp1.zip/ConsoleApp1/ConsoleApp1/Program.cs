﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(".................. 1..................");
            ResearchTeam one = new ResearchTeam();//Создать один объект типа ResearchTeam
            Console.WriteLine(one.ToShortString() + "\n");

            Console.WriteLine(".................. 2..................");
            Console.WriteLine(one[TimeFrame.Year]);//Вывести значения индексатора
            Console.WriteLine(one[TimeFrame.TwoYears]);
            Console.WriteLine(one[TimeFrame.Long] + "\n");

            Console.WriteLine(".................. 3..................");
            one.Topic = "Tema1";//Присвоить значения всем определенным в типе ResearchTeam свойствам
            one.Organization = "OAO Apelsinka";
            one.Number = 77777;
            one.Time = TimeFrame.Long;
            Paper[] List1 = new Paper[2];
            List1[0] = new Paper("Book1", new Person("Name1", "Surname1", new DateTime(2020, 1, 1)), new DateTime(2079, 10, 11));
            List1[1] = new Paper("Book2", new Person("Name2", "Surname2", new DateTime(2020, 2, 2)), new DateTime(2079, 12, 22));
            one.List = List1;
            Console.WriteLine(one.ToString() + "\n");
            //С помощью метода AddPaper(params Paper[]) добавить элементы в список публикаций и вывести данные объекта ResearchTeam
            Console.WriteLine(".................. 4..................");
            Paper Book1 = new Paper("Book3", new Person("Name3","Surname3",new DateTime(2020,3,3)), new DateTime(2079, 03, 13));
            Paper Book2 = new Paper("Book4", new Person("Name4", "Surname4", new DateTime(2020, 4, 4)), new DateTime(2079, 04, 24));
            one.AddPaper(Book1, Book2);
            Console.WriteLine(one.ToString() + "\n");

            Console.WriteLine(".................. 5..................");
            Console.WriteLine(one.ReturnPublic.ToString() + "\n");

            //Сравнить время выполнения операций с элементами одномерного,двумерного прямоугольного и двумерного ступенчатого массивов с одинаковым числом элементов типа Paper
            Console.WriteLine(".................. 6..................");
            int line = 0, column = 0;
            Console.WriteLine("Введите число строк и столбцов, через один из разделителей(','  ';' ':' ' ')");
            string input = Console.ReadLine();
            string[] value = input.Split(':', ';', ',',' ');
            line = int.Parse(value[0]);
            column = int.Parse(value[1]);

            int size = line * column;
            Paper[] Mas1 = new Paper[size];
            Paper[,] Mas2 = new Paper[line, column];
            Paper[][] Mas3 = new Paper[line][];

            //одномерный массив
            for (int i = 0; i < size; i++)
                Mas1[i] = new Paper(); 

            //двумерный массив
            for (int i = 0; i < line; i++)
                for (int j = 0; j < column; j++)
                    Mas2[i, j] = new Paper();

            //ступенчатый массив
            for (int i = 0; i < line; i++)
            { 
                Mas3[i] = new Paper[column];
               for (int j = 0; j < column; j++)
                    Mas3[i][j] = new Paper();

            }

            long Time1 = 0, Time2 = 0, Time3 = 0;
            Stopwatch timer = new Stopwatch();

            string name = "Name";

            //одномерный массив
            timer.Start();
            for (int i = 0; i < size; i++)
                Mas1[i].name = name;
            timer.Stop();
            Time1 = timer.ElapsedMilliseconds;
            timer.Reset();


            //двумерный массив
            timer.Start();
            for (int i = 0; i < line; i++)
                for (int j = 0; j < column; j++)
                    Mas2[i, j].name = name;
            timer.Stop();
            Time2 = timer.ElapsedMilliseconds;
            timer.Reset();

            //cтупенчатый массив
            timer.Start();
            for (int i = 0; i < line; i++)
                for (int j = 0; j < column; j++)
                    Mas3[i][j].name = name;
            timer.Stop();
            Time3 = timer.ElapsedMilliseconds;
            timer.Reset();

            Console.WriteLine("Время выполнения оперций (в миллисекундах)");
            Console.WriteLine("Одномерный массив: " + Time1);
            Console.WriteLine("Двумерный массив: " + Time2);
            Console.WriteLine("Ступенчатый массив: " + Time3);
        }
    }
}
