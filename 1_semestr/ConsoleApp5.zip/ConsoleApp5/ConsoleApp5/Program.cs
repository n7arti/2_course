﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5 
{
    class Program
    {
        static void Main(string[] args)
        {
            Person per1 = new Person("Name4", "Surname1", new DateTime(1991, 1, 1));
            Person per2 = new Person("Name2", "Surname2", new DateTime(1992, 2, 2));
            Person per3 = new Person("Name3", "Surname3", new DateTime(1993, 3, 3));
            Person per4 = new Person("Name1", "Surname4", new DateTime(1994, 4, 4));
            Person per5 = new Person();

            Paper pap1 = new Paper();
            Paper pap2 = new Paper("topic5", per1, new DateTime(2011, 1, 1));
            Paper pap3 = new Paper("topic2", per4, new DateTime(2012, 2, 2));
            Paper pap4 = new Paper("topic4", per5, new DateTime(2013, 3, 3));
            Paper pap5 = new Paper("topic3", per2, new DateTime(2014, 4, 4));

            
            //Создать полную копию объекта с помощью метода, использующего сериализацию, и вывести исходныйобъект и его копию
            Console.WriteLine(".................. 1..................");
            ResearchTeam RT = new ResearchTeam("RT1", "Org1", 111, TimeFrame.Year);
            RT.AddMembers(per4, per1, per2, per3, per5);
            RT.AddPaper(pap5, pap4, pap2, pap1, pap3); 
            Console.WriteLine(RT);
            Console.WriteLine(RT.DeepCopy());

            Console.WriteLine(".................. 2..................");// Предложить пользователю ввести имя файла 
            Console.WriteLine("Введите название файла: ");
            string filename = Console.ReadLine();
            if (System.IO.File.Exists(filename))
            {
                if (RT.Load(filename))
                {
                    Console.WriteLine("Файл существует.");
                }
            }
            else
            {
                Console.WriteLine("Файл создан");
                System.IO.File.Create(filename);
            }

            Console.WriteLine(".................. 3..................");//Вывести объект RT
            Console.WriteLine(RT);

            //Для этого же объекта сначала вызвать метод AddFromConsole(), затем метод Save(string filename). Вывести объект
            Console.WriteLine(".................. 4..................");
            RT.AddFromConsole();
            RT.Save(filename);
            Console.WriteLine(RT);

            Console.WriteLine(".................. 5..................");//Вызвать методы
            if (ResearchTeam.Load(filename, RT))
            {
                if (RT.AddFromConsole())
                {
                    ResearchTeam.Save(filename, RT);
                }
            }
            Console.WriteLine(RT);

        }
    }
}
