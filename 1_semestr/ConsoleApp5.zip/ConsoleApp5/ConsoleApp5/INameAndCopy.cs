﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp5
{
    interface INameAndCopy
    {
        string Name { get; set; }
        object DeepCopy();
    }
}

