﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp5
{
    class TeamsJournal
    {
        private List<TeamsJournalEntry> listChanges = new List<TeamsJournalEntry>();
        public void OnPropertyChange(object source, ResearchTeamsChangedEventArgs<string> obj)
        {

            TeamsJournalEntry teamJE = new TeamsJournalEntry(obj.Namecollect, obj.Reason, obj.NameRT, obj.NumbregRT);
            listChanges.Add(teamJE);
        }
        public override string ToString()
        {
            string result = "";
            foreach (TeamsJournalEntry i in listChanges)
            {
                result += i.ToString() + "\n\n";
            }
            return result;
        }
    }
}
