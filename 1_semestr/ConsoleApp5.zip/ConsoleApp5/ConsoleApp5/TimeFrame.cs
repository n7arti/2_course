﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp5
{
    enum TimeFrame { Year, TwoYears, Long };
}
