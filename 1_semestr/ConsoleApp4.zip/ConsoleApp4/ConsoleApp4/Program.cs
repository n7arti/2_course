﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            Person per1 = new Person("Name4", "Surname1", new DateTime(1991, 1, 1));
            Person per2 = new Person("Name2", "Surname2", new DateTime(1992, 2, 2));
            Person per3 = new Person("Name3", "Surname3", new DateTime(1993, 3, 3));
            Person per4 = new Person("Name1", "Surname4", new DateTime(1994, 4, 4));
            Person per5 = new Person();

            Paper pap1 = new Paper();
            Paper pap2 = new Paper("topic5", per1, new DateTime(2011, 1, 1));
            Paper pap3 = new Paper("topic2", per4, new DateTime(2012, 2, 2));
            Paper pap4 = new Paper("topic4", per5, new DateTime(2013, 3, 3));
            Paper pap5 = new Paper("topic3", per2, new DateTime(2014, 4, 4));

            ResearchTeam RT1 = new ResearchTeam("RT1", "Org1", 111, TimeFrame.Year);
            RT1.AddMembers(per4, per1, per2, per3,per5);
            RT1.AddPaper(pap5, pap4, pap2, pap1, pap3);

            ResearchTeam RT2 = new ResearchTeam("RT2", "Org2", 222, TimeFrame.TwoYears);
            RT2.AddMembers(per1, per2, per3);
            RT2.AddPaper(pap5, pap4, pap3);

            ResearchTeam RT3 = new ResearchTeam("RT3", "Org3", 333, TimeFrame.Long);
            RT3.AddMembers(per4,per5);
            RT3.AddPaper(pap1, pap2, pap3);

            ResearchTeam RT4 = new ResearchTeam("RT4", "Org4", 444, TimeFrame.Year);
            RT3.AddMembers(per4, per2);
            RT3.AddPaper(pap1, pap2);

            ResearchTeam RT5 = new ResearchTeam("RT5", "Org5", 555, TimeFrame.TwoYears);
            RT3.AddMembers(per5, per1);
            RT3.AddPaper(pap5, pap2);

            Console.WriteLine(".................. 1..................");//Создать две коллекции ResearchTeamCollection<string> 
            KeySelector<string> XD = ResearchTeamCollections<string>.GenerateKey;
            ResearchTeamCollections<string> RTC1 = new ResearchTeamCollections<string>(XD);
            RTC1.AddResearchTeams(RT1, RT2, RT3);
            RTC1.Namecollect = "Collection 1";
            Console.WriteLine(RTC1.ToString());
            ResearchTeamCollections<string> RTC2 = new ResearchTeamCollections<string>(XD);
            RTC2.AddResearchTeams(RT2, RT3);
            RTC2.Namecollect = "Collection 2";
            Console.WriteLine(RTC2.ToString());

            Console.WriteLine(".................. 2..................");// Создать объект TeamsJournal, подписать его на события 
            TeamsJournal TJ = new TeamsJournal();
            RTC1.ResearchTeamsChanged += TJ.OnPropertyChange;
            RTC2.ResearchTeamsChanged += TJ.OnPropertyChange;

            Console.WriteLine(".................. 3..................");//Внести изменения в коллекции
            //добавить элементы в коллекции
            RTC1.AddResearchTeams(RT4);
            RTC2.AddResearchTeams(RT1);
            //изменить значения разных свойств элементов, входящих в коллекцию
            RT1.Time = TimeFrame.Long;
            RT2.Registnumb = 67890;
            RT3.Topic = "New Topic";
            RT4.Registnumb = 555555;
            //удалить элемент из коллекции
            RTC1.Remove(RT1);
            RTC2.Remove(RT2);
            //изменить данные в удаленном элементе
            RT2.Topic = "Rem Topic";
            //заменить один из элементов коллекци
            RTC1.Replace(RT2, RT5);
            //изменить данные в элементе, который был удален из коллекции при замене элемента
            RT2.Topic = "Rep Topic";
            Console.WriteLine(".................. 4..................");//Вывести данные объекта TeamsJournal
            Console.WriteLine(TJ.ToString());

        }
    }
}
