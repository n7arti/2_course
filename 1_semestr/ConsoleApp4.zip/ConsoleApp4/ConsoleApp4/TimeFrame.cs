﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp4
{
    enum TimeFrame { Year, TwoYears, Long };
}
