﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    delegate TKey KeySelector<TKey>(ResearchTeam rt);
    class ResearchTeamCollections<TKey>
    {
        private System.Collections.Generic.Dictionary<TKey, ResearchTeam> resTK;
        private KeySelector<TKey> xdel;
        public ResearchTeamCollections(KeySelector<TKey> xdel_value)
        {
            xdel = xdel_value;
            resTK = new Dictionary<TKey, ResearchTeam>();
        }
        public string Namecollect { get; set; }
        public event ResearchTeamsChangedHandler<TKey> ResearchTeamsChanged;
        public void OnPropertyChange(object rt, System.ComponentModel.PropertyChangedEventArgs args)
        {

            ResearchTeam rt1 = rt as ResearchTeam;
            ResearchTeamsChanged(rt, new ResearchTeamsChangedEventArgs<TKey>(Namecollect, Revision.Property, args.PropertyName, rt1.Registnumb));
        }
        public void AddDefaults()
        {
            ResearchTeam rt = new ResearchTeam();
            TKey key = xdel(rt);
            resTK.Add(key, rt);
        }
        public void AddResearchTeams(params ResearchTeam[] rt)
        {
            for(int i = 0; i < rt.Length; i++)
            {
                TKey key = xdel(rt[i]);
                resTK.Add(key, rt[i]);
                rt[i].PropertyChanged += this.OnPropertyChange;
            }
        }
        public override string ToString()
        {

            Dictionary<TKey, ResearchTeam>.ValueCollection collect = resTK.Values;
            string str = "";
            foreach (ResearchTeam i in collect)
            {
                str += i.ToString() + "\n\n";
            }
            return str;
        }
        public string ToShortString()
        {
            Dictionary<TKey, ResearchTeam>.ValueCollection collect = resTK.Values;
            string str = "";
            foreach (ResearchTeam i in collect)
            {
                str += i.ToShortString() + " " + i.PersonList.Count + " " + i.PaperList.Count + "\n\n";
            }
            return str;
        }
        public DateTime LastPubl
        {
            get
            {
                Dictionary<TKey, ResearchTeam>.ValueCollection collect = resTK.Values;
                if (collect.Count == 0)
                {
                    return new DateTime();
                }
                else
                {
                    List<Paper> PList = new List<Paper>();

                    foreach (ResearchTeam rt in collect)
                    {
                        PList.Add(rt.ReturnPublic);
                    }
                    return PList.Max(p => p.Date);
                }


            }
        }
        public IEnumerable<KeyValuePair<TKey, ResearchTeam>> TimeFrameGroup(TimeFrame value)
        {
            return resTK.Where(p => p.Value.Time == value);
        }
        public IEnumerable<IGrouping<TimeFrame, KeyValuePair<TKey, ResearchTeam>>> Group
        {
            get
            {
                return resTK.GroupBy(p=> p.Value.Time);
            }
        }
        public static string GenerateKey(ResearchTeam rt)
        {
            return rt.Group.ToString();
        }
        public bool Remove(ResearchTeam rt)
        {
            if (resTK.ContainsValue(rt))
            {
                foreach (KeyValuePair<TKey, ResearchTeam> i in resTK)
                {
                    if (i.Value == rt)
                    {
                        ResearchTeamsChanged(resTK, new ResearchTeamsChangedEventArgs<TKey>(Namecollect, Revision.Remove, "None", rt.Registnumb));
                        resTK.Remove(i.Key);
                        break;
                    }
                }
                return true;
            }
            else
                return false;
        }
        public bool Replace(ResearchTeam rt1, ResearchTeam rt2)
        {
            if (resTK.ContainsValue(rt1))
            {
                foreach (KeyValuePair<TKey, ResearchTeam> i in resTK)
                {
                    if (i.Value == rt1)
                    {
                        resTK.Remove(i.Key);
                        AddResearchTeams(rt2);
                        ResearchTeamsChanged(resTK, new ResearchTeamsChangedEventArgs<TKey>(Namecollect, Revision.Replace, "None", rt1.Registnumb));
                        break;

                    }
                }
                return true;
            }
            else
                return false;
        }
    }
}
