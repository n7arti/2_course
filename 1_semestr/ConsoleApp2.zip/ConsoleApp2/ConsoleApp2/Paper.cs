﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    class Paper
    {
        public string name { get; set; }//автореализуемые свойства
        public Person author { get; set; }
        public DateTime date { get; set; }
        public Paper(string name_value, Person author_value, DateTime date_value)//конструктор с параметром
        {
            name = name_value;
            author = author_value;
            date = date_value;
        }
        public Paper()//конструктор без параметров
        {
            name = "Dorian Gray";
            author = new Person("Oscar", "Wilde", new DateTime(1854, 10, 16));
            date = new DateTime(1890, 6, 20);
        }
        public override string ToString()//перегруженная версия виртуального метода string ToString
        {
            return name + " " + author.ToString() + " " + date.ToString("d");
        }
        public virtual object DeepCopy() // виртуальный метод object DeepCopy().
        {
            Paper PaperCopy = new Paper();
            PaperCopy.name = this.name;
            PaperCopy.author = this.author;
            PaperCopy.date = this.date;
            return PaperCopy;
        }
    }
}
