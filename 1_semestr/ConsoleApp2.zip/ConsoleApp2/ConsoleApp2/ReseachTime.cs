﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Collections;

namespace ConsoleApp2
{
    class ReseachTime: Team, IEnumerable
    {
        private string topic;//закрытые поля
        private TimeFrame time;
        System.Collections.ArrayList personList;
        System.Collections.ArrayList paperList;
        public ReseachTime(string topic_value, string nameorg_value, int registnumb_value, TimeFrame time_value, System.Collections.ArrayList personList_value,
            System.Collections.ArrayList paperList_value)//конструктор с параметрами
        {
            topic = topic_value;
            nameorg = nameorg_value;
            registnumb = registnumb_value;
            time = time_value;
            personList = personList_value;
            paperList = paperList_value;
        }
        public ReseachTime() //конструктор без параметров
        {
            topic = "Tema";
            nameorg = "OAO Apelsin";
            registnumb = 66666666;
            time = TimeFrame.Year;
            personList = new System.Collections.ArrayList();
            paperList = new System.Collections.ArrayList();
        }
        public string Topic//свойства с методами get и set
        {
            get
            {
                return topic;
            }
            set
            {
                topic = value;
            }
        }
        public TimeFrame Time
        {
            get
            {
                return time;
            }
            set
            {
                time = value;
            }
        }
        public System.Collections.ArrayList PersonList
        {
            get
            {
                return personList;
            }
            set
            {
                personList = value;
            }
        }
        public System.Collections.ArrayList PaperList
        {
            get
            {
                return paperList;
            }
            set
            {
                paperList = value;
            }
        }
        public Paper ReturnPublic//свойство типа Paper ( только с методом get), которое возвращает ссылку на публикацию с самой поздней датой выхода
        {
            get
            {
                Paper link = new Paper();
                if (paperList.Count == 0)
                    return null;
                else
                {
                    DateTime datemin = DateTime.MinValue;
                    foreach (Paper value in paperList)
                        if (value.date > datemin)
                        {
                            datemin = value.date;
                            link = value;
                        }
                    return link;
                }
            }
        }
        public bool this[TimeFrame time_value]//индексатор булевского типа 
        {
            get
            {
                return Time == time_value;
            }
        }
        public void AddPaper(params Paper[] NewPaper)//метод добавления элементов в список публикаций
        {
            foreach (Paper i in NewPaper)
                paperList.Add(i);
        }
        public void AddMembers(params Person[] NewPerson)//метод добавления элементов в список участников
        {
            foreach (Person i in NewPerson)
                personList.Add(i);
        }
        public override string ToString()//перегруженная версия виртуального метода string ToString()
        {
            string line = topic + " " + nameorg+ " " + registnumb.ToString() + " " + time.ToString() + "\n";
            for (int i = 0; i < paperList.Count; i++)
                line += paperList[i].ToString() + "\n";
            for (int i = 0; i < personList.Count; i++)
                line += personList[i].ToString() + "\n";
            return line;
        }
        public virtual string ToShortString()//виртуальный метод string ToShortString()
        {
            return topic + " " + nameorg + " " + registnumb.ToString() + " " + time.ToString();
        }
        public override object DeepCopy()
        {
            ReseachTime ReseachTimeCopy = new ReseachTime();
            ReseachTimeCopy.topic = this.topic;
            ReseachTimeCopy.nameorg = this.nameorg;
            ReseachTimeCopy.registnumb = this.registnumb;
            ReseachTimeCopy.time = this.time;
            ReseachTimeCopy.paperList = this.paperList;
            ReseachTimeCopy.personList = this.personList;
            return ReseachTimeCopy;
        }
        public Team Group
        {
            get
            {
                Team group = new Team(this.nameorg, this.registnumb);
                return group;
            }
            set
            {
                nameorg = value.Nameorg;
                registnumb = value.Registnumb;
            }
        }
        public IEnumerable GetEnumeratornull()
        {
            for (int i = 0; i < personList.Count; i++)
            {
                bool t = false;
                for (int j = 0; j < paperList.Count; j++)
                {
                    if ((paperList[j] as Paper).author.Equals((Person)personList[i]))
                    {
                        t = true;
                        break;
                    }
                }

                if (!t)
                    yield return personList[i];
            }
        }
        public IEnumerable<Paper> YearEnumerator(int Timeh)
        {
            Paper[] List = new Paper[paperList.Count];
            int k = 0;
            foreach (Paper i in paperList)
            {
                List[k] = i;
                k++;
            }
            int Yearrnow = DateTime.Now.Year - Timeh;
            for (int i = 0; i < paperList.Count; i++)
            {

                if (List[i].date.Year > Yearrnow )
                    yield return List[i];
            }
        }
        public IEnumerable GetEnumeratorpubl()
        {
            for (int i = 0; i < personList.Count; i++)
            {
                int papcount = 0;
                for (int j = 0; j < PaperList.Count; j++)
                {
                    if ((paperList[j] as Paper).author.Equals((Person)personList[i]))
                    {
                        papcount++;
                    }
                }

                if (papcount > 1)
                    yield return personList[i];
            }
        }
        public IEnumerable<Paper> LastPaper()
        {
            foreach (Paper i in paperList)
              if (i.date.Year == DateTime.Now.Year)
                yield return i;
        }
        public IEnumerator GetEnumerator()
        {
            return new ResearchTimeEnumerator(personList, paperList);
        }
        class ResearchTimeEnumerator : IEnumerator
        {
            private ArrayList persons;
            private ArrayList papers;
            int position = -1;
            public ResearchTimeEnumerator(ArrayList persons_value, ArrayList papers_value)
            {
                persons = persons_value;
                papers = papers_value;
            }
            public bool MoveNext()
            {
                position++;
                if (position < persons.Count - 1)
                {
                    bool t = false;
                    while (position < persons.Count)
                    {
                        for (int i = 0; i < papers.Count; i++)
                        {
                            if ((papers[i] as Paper).author.Equals((Person)Current))
                            {
                                t = true;
                                break;
                            }
                        }

                        if (t)
                            break;
                        else
                            position++;
                    }

                    if (t)
                        return true;
                    else
                        return false;
                }
                else
                {
                    return false;
                }

            }
            public void Reset()
            {
                position = -1;
            }
            public object Current
            {
                get
                {
                    return persons[position];

                }
            }
        }
    }
    
}
