﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(".................. 1..................");
            Team one = new Team();//Создать два объекта типа Team
            Team two = new Team();
            Console.WriteLine("Равенство объектов: {0}", one.Equals(two));
            Console.WriteLine("Равенство ссылок: {0}", System.Object.ReferenceEquals(one, two));
            Console.WriteLine("Хэш код первого объекта: {0}, второго объекта: {1}", one.GetHashCode(), two.GetHashCode());

            Console.WriteLine(".................. 2..................");
            one.Registnumb = 0;//присвоить свойству с номером регистрации некорректное значение

            Console.WriteLine(".................. 3..................");
            ReseachTime RT1 = new ReseachTime();//Создать объект типа ResearchTeam, добавить элементы в список
            Person ppp = new Person("RRR", "KKK", new DateTime(2001, 8, 18));
            RT1.AddPaper(new Paper("Book", ppp, new DateTime(2020, 2, 2)));
            RT1.AddMembers(new Person("Name", "Surname", new DateTime(2000, 1, 1)));
            Console.WriteLine(RT1.ToString());

            Console.WriteLine(".................. 4..................");
            Console.WriteLine(RT1.Group.ToString());//Вывести значение свойства Team для объекта типа ResearchTeam

            Console.WriteLine(".................. 5..................");
            ReseachTime RT2 = (ReseachTime)RT1.DeepCopy();//С помощью метода DeepCopy() создать полную копию объекта ResearchTeam
            RT1.Topic = "TTT";
            RT1.Nameorg = "XXX";
            RT1.Registnumb = 55;
            RT1.Time = TimeFrame.Long;
            Console.WriteLine(RT1.ToString());
            Console.WriteLine(RT2.ToString());

            Console.WriteLine(".................. 6..................");
            foreach (Person i in RT1.GetEnumeratornull())//вывести список участников проекта, которые не имеют публикаций
                Console.WriteLine(i.ToString()); 

            Console.WriteLine(".................. 7..................");
            RT1.AddPaper(new Paper("Book1", ppp, new DateTime(2010, 2, 2)));
            RT1.AddMembers(ppp);
            foreach (Paper i in RT1.YearEnumerator(2))//вывести список всех публикаций, вышедших за последние два года
                Console.WriteLine(i.ToString());

            Console.WriteLine(".................. 8..................");
            foreach (Person i in RT1)//вывести список участников проекта, у которых есть публикации
                Console.WriteLine(i.ToString());

            Console.WriteLine(".................. 9..................");
            foreach (Person i in RT1.GetEnumeratorpubl())//вывести список участников проекта, имеющих более одной публикации
                Console.WriteLine(i.ToString());
            Console.WriteLine(".................. 10..................");
            foreach (Paper i in RT1.LastPaper())//вывести список публикаций, вышедших за последний год
                Console.WriteLine(i.ToString());
        }
    }
}
