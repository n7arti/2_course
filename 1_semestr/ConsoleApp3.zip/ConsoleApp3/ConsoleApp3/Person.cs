﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3
{
    class Person
    {
        private string name;
        private string surname;
        private DateTime birthday;

        public Person(string name_value, string surname_value, DateTime birthday_value)
        {
            name = name_value;
            surname = surname_value;
            birthday = birthday_value;
        }

        public Person()
        {
            name = "Ivan";
            surname = "Ivanov";
            birthday = new DateTime(2000, 1, 1);
        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public string Surname
        {
            get
            {
                return surname;
            }
            set
            {
                surname = value;
            }
        }

        public DateTime Birthday
        {
            get
            {
                return birthday;
            }
            set
            {
                birthday = new DateTime(birthday.Year, birthday.Month, birthday.Day);
            }
        }
        public int ChangeYear
        {
            get
            {
                return birthday.Year;
            }
            set
            {
                birthday = new DateTime(value, birthday.Month, birthday.Day);
            }
        }

        public override string ToString()
        {
            return name + " " + surname + " " + birthday.ToString("d");
        }
        public virtual string ToShortString()
        {
            return name + " " + surname;
        }
        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            Person person1 = obj as Person;// возвращает null если объект нельзя привести к типу Person
            if (person1 as Person == null)
                return false;

            return (person1.name == this.name) && (person1.surname == this.surname) && (person1.birthday == this.birthday);
        }

        public static bool operator ==(Person p1, Person p2)
        {
            if (object.ReferenceEquals(p1, null))
            {
                if (object.ReferenceEquals(p2, null))
                    return true;
                return false;
            }
            return p1.Equals(p2);
        }
        public static bool operator !=(Person p1, Person p2)
        {
            return !(p1 == p2);
        }

        public override int GetHashCode()
        {
            return name.GetHashCode() + surname.GetHashCode() + birthday.GetHashCode();
        }
        public object DeepCopy()
        {
            Person PersonCopy = new Person();
            PersonCopy.name = this.name;
            PersonCopy.surname = this.surname;
            PersonCopy.birthday = this.birthday;
            return PersonCopy;
        }
    }
}

