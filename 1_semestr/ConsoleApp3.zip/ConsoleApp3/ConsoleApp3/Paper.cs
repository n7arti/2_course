﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3
{
    class Paper: IComparable<Paper>, IComparer<Paper>
    {
        public string Name { get; set; }//автореализуемые свойства
        public Person Author { get; set; }
        public DateTime Date { get; set; }
        public Paper(string name_value, Person author_value, DateTime date_value)//конструктор с параметром
        {
            Name = name_value;
            Author = author_value;
            Date = date_value;
        }
        public Paper()//конструктор без параметров
        {
            Name = "Dorian Gray";
            Author = new Person("Oscar", "Wilde", new DateTime(1854, 10, 16));
            Date = new DateTime(1890, 6, 20);
        }
        public override string ToString()//перегруженная версия виртуального метода string ToString
        {
            return Name + " " + Author.ToString() + " " + Date.ToString("d");
        }
        public virtual object DeepCopy() // виртуальный метод object DeepCopy().
        {
            Paper PaperCopy = new Paper(this.Name, this.Author,this.Date);
            return PaperCopy;
        }
        public int CompareTo(Paper p)//сравнениe по дате выхода публикации
        {
            return this.Date.CompareTo(p.Date);
        }
        public int Compare(Paper p1, Paper p2) //сравнениe по названию публикации
        {
            return String.Compare(p1.Name, p2.Name);
        }
    }
}
