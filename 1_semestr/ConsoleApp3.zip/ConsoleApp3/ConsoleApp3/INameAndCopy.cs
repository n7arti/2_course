﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3
{
    interface INameAndCopy
    {
        string Name { get; set; }
        object DeepCopy();
    }
}

