﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    delegate System.Collections.Generic.KeyValuePair<TKey, TValue> GenerateElement<TKey, TValue>(int j);

    class TestCollections<TKey, TValue>
    {
        private System.Collections.Generic.List<TKey> keyList;
        private System.Collections.Generic.List<string> strList;
        private System.Collections.Generic.Dictionary<TKey, TValue> keyvaldic;
        private System.Collections.Generic.Dictionary<string, TValue> strvaldic;
        private GenerateElement<TKey, TValue> keyvalel;

        public TestCollections(GenerateElement<TKey, TValue> keyvalel_value)
        {
            Console.WriteLine("Введите число элементов коллекций\n");
            int n = Convert.ToInt32(Console.ReadLine());
            while (n <= 0)
            {
                Console.WriteLine("Не корректный ввод. Попробуйте снова.\n");
                n = Convert.ToInt32(Console.ReadLine());
            }
            keyList = new List<TKey>(n);
            strList = new List<string>(n);
            keyvaldic = new Dictionary<TKey, TValue>(n);
            strvaldic = new Dictionary<string, TValue>(n);

            keyvalel = keyvalel_value;
            KeyValuePair<TKey, TValue> kvp;
            for (int i = 0; i < n; i++)
            {
                kvp = keyvalel.Invoke(i);
                keyList.Add(kvp.Key);
                strList.Add(kvp.Key.ToString());
                keyvaldic.Add(kvp.Key, kvp.Value);
                strvaldic.Add(kvp.Key.ToString(), kvp.Value);
            }
        }
        public static KeyValuePair<Team, ResearchTeam> Generate(int n)
        {
            ResearchTeam rt = new ResearchTeam();
            return new KeyValuePair<Team, ResearchTeam>(rt.Group, rt);
        }
        public void TimeContains(TKey n)
        {
            long t1 = DateTime.Now.Ticks;
            keyList.Contains(keyList.First());
            long t2 = DateTime.Now.Ticks;
            Console.WriteLine("Время поиска первого элемента в коллекции List<TKey> :    {0:N0} ns", (t2 - t1) * 100);

            t1 = DateTime.Now.Ticks;
            strList.Contains(strList.First());
            t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска первого элемента в коллекции List<string> :    {0:N0} ns", (t2 - t1) * 100);

            t1 = DateTime.Now.Ticks;
            keyList.Contains(keyList[Convert.ToInt32(Math.Ceiling((double)keyList.Count / (double)2))]);
            t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска среднего элемента в коллекции List<TKey> :    {0:N0} ns", (t2 - t1) * 100);

            t1 = DateTime.Now.Ticks;
            strList.Contains(strList[Convert.ToInt32(Math.Ceiling((double)strList.Count / (double)2))]);
            t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска среднего элемента в коллекции List<string> :    {0:N0} ns", (t2 - t1) * 100);

            t1 = DateTime.Now.Ticks;
            keyList.Contains(keyList.Last());
            t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска последнего элемента в коллекции List<TKey> :    {0:N0} ns", (t2 - t1) * 100);

            t1 = DateTime.Now.Ticks;
            strList.Contains(strList.Last());
            t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска последнего элемента в коллекции List<string> :    {0:N0} ns", (t2 - t1) * 100);

            t1 = DateTime.Now.Ticks;
            keyList.Contains(n);
            t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска элемента, не входящего в коллекцию List<TKey> :    {0:N0} ns", (t2 - t1) * 100);

            t1 = DateTime.Now.Ticks;
            strList.Contains("abcdef");
            t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска элемента, не входящего в коллекцию List<string> :    {0:N0} ns", (t2 - t1) * 100);
        }
        public void TimeContainsKey(TKey n)
        {
            Dictionary<TKey, TValue>.KeyCollection collect1 = keyvaldic.Keys;
            Dictionary<string, TValue>.KeyCollection collect2 = strvaldic.Keys;
            long t1 = DateTime.Now.Ticks;
            keyvaldic.ContainsKey(collect1.First());
            long t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска первого элемента по ключу в коллекции Dictionary<TKey, TValue> :    {0:N0} ns", (t2 - t1) * 100);

            t1 = DateTime.Now.Ticks;
            strvaldic.ContainsKey(collect2.First());
            t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска первого элемента по ключу в коллекции Dictionary<string, TValue> :    {0:N0} ns", (t2 - t1) * 100);

            t1 = DateTime.Now.Ticks;
            keyvaldic.ContainsKey(collect1.ElementAt(Convert.ToInt32(Math.Ceiling((double)collect1.Count / (double)2))));
            t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска среднего элемента по ключу в коллекции Dictionary<TKey, TValue> :    {0:N0} ns", (t2 - t1) * 100);

            t1 = DateTime.Now.Ticks;
            strvaldic.ContainsKey(collect2.ElementAt(Convert.ToInt32(Math.Ceiling((double)collect2.Count / (double)2))));
            t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска среднего элемента по ключу в коллекции Dictionary< string, TValue> :    {0:N0} ns", (t2 - t1) * 100);

            t1 = DateTime.Now.Ticks;
            keyvaldic.ContainsKey(collect1.Last());
            t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска последнего элемента по ключу в коллекции Dictionary<TKey, TValue> :    {0:N0} ns", (t2 - t1) * 100);

            t1 = DateTime.Now.Ticks;
            strvaldic.ContainsKey(collect2.Last());
            t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска последнего элемента по ключу в коллекции Dictionary<string, TValue> :    {0:N0} ns", (t2 - t1) * 100);

            t1 = DateTime.Now.Ticks;
            keyvaldic.ContainsKey(n);
            t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска элемента, не входящего в коллекцию по ключу Dictionary<TKey, TValue> :    {0:N0} ns", (t2 - t1) * 100);

            t1 = DateTime.Now.Ticks;
            strvaldic.ContainsKey("abcdef");
            t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска элемента, не входящего в коллекцию по ключу Dictionary<string, TValue> :    {0:N0} ns", (t2 - t1) * 100);
        }
        public void TimeContainsValue()
        {
            Dictionary<TKey, TValue>.ValueCollection collect = keyvaldic.Values;
            long t1 = DateTime.Now.Ticks;
            keyvaldic.ContainsValue(collect.First());
            long t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска первого элемента по значению в коллекции Dictionary< TKey, TValue> :    {0:N0} ns", (t2 - t1) * 100);

            t1 = DateTime.Now.Ticks;
            keyvaldic.ContainsValue(collect.ElementAt(Convert.ToInt32(Math.Ceiling((double)collect.Count / (double)2))));
            t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска среднего элемента по значению в коллекции Dictionary< TKey, TValue> :    {0:N0} ns", (t2 - t1) * 100);

            t1 = DateTime.Now.Ticks;
            keyvaldic.ContainsValue(collect.Last());
            t2 = DateTime.Now.Ticks;
            Console.WriteLine("Bремя поиска последнего элемента по значению в коллекции Dictionary< TKey, TValue> :    {0:N0} ns", (t2 - t1) * 100);
        }
    }
}
