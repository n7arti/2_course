﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class ComparerPaper: IComparer<Paper>
    {
        public int Compare(Paper p1, Paper p2)
        {
            return String.Compare(p1.Author.Surname, p2.Author.Surname);
        }
    }
}
