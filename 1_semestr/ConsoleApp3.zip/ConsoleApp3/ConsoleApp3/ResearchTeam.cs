﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Collections;

namespace ConsoleApp3
{
    class ResearchTeam : Team, IEnumerable, INameAndCopy
    {
        private string topic;//закрытые поля
        private TimeFrame time;
        System.Collections.Generic.List<Person> personList = new List<Person>();
        System.Collections.Generic.List<Paper> paperList = new List<Paper>();
        public ResearchTeam(string topic_value, string nameorg_value, int registnumb_value, TimeFrame time_value)//конструктор с параметрами
        {
            topic = topic_value;
            nameorg = nameorg_value;
            registnumb = registnumb_value;
            time = time_value;
        }
        public ResearchTeam() //конструктор без параметров
        {
            topic = "Tema";
            nameorg = "OAO Apelsin";
            registnumb = 66666666;
            time = TimeFrame.Year;
        }
        public string Topic//свойства с методами get и set
        {
            get
            {
                return topic;
            }
            set
            {
                topic = value;
            }
        }
        public TimeFrame Time
        {
            get
            {
                return time;
            }
            set
            {
                time = value;
            }
        }
        public System.Collections.Generic.List<Person> PersonList
        {
            get
            {
                return personList;
            }
            set
            {
                personList = value;
            }
        }
        public System.Collections.Generic.List<Paper> PaperList
        {
            get
            {
                return paperList;
            }
            set
            {
                paperList = value;
            }
        }
        public Paper ReturnPublic//свойство типа Paper ( только с методом get), которое возвращает ссылку на публикацию с самой поздней датой выхода
        {
            get
            {
                Paper link = new Paper();
                if (paperList.Count == 0)
                    return null;
                else
                {
                    DateTime datemin = DateTime.MinValue;
                    foreach (Paper value in paperList)
                        if (value.Date > datemin)
                        {
                            datemin = value.Date;
                            link = value;
                        }
                    return link;
                }
            }
        }
        public void SortDate()
        {
            this.paperList.Sort();
        }
        public void SortName()
        {
            this.paperList.Sort(new Paper());
        }
        public void SortAuthor()
        {
            this.paperList.Sort(new ComparerPaper());
        }

        public bool this[TimeFrame time_value]//индексатор булевского типа 
        {
            get
            {
                return Time == time_value;
            }
        }
        public void AddPaper(params Paper[] NewPaper)//метод добавления элементов в список публикаций
        {
            for (int i = 0; i < NewPaper.Length; i++)
                paperList.Add(NewPaper[i]);
        }
        public void AddMembers(params Person[] NewPerson)//метод добавления элементов в список участников
        {
            for (int i = 0; i < NewPerson.Length; i++)
                this.personList.Add(NewPerson[i]);
        }
        public override string ToString()//перегруженная версия виртуального метода string ToString()
        {
            string line = topic + " " + nameorg + " " + registnumb.ToString() + " " + time.ToString() + "\n";
            for (int i = 0; i < paperList.Count; i++)
                line += paperList[i].ToString() + "\n";
            for (int i = 0; i < personList.Count; i++)
                line += personList[i].ToString() + "\n";
            return line;
        }
        public virtual string ToShortString()//виртуальный метод string ToShortString()
        {
            return topic + " " + nameorg + " " + registnumb.ToString() + " " + time.ToString();
        }
        string INameAndCopy.Name
        {
            get
            { 
                return topic; 
            }
            set 
            { 
                topic = value; 
            }
        }
        public override object DeepCopy()
        {
            ResearchTeam ResearchTeamCopy = new ResearchTeam();
            ResearchTeamCopy.topic = this.topic;
            ResearchTeamCopy.nameorg = this.nameorg;
            ResearchTeamCopy.registnumb = this.registnumb;
            ResearchTeamCopy.time = this.time;
            ResearchTeamCopy.paperList = this.paperList;
            ResearchTeamCopy.personList = this.personList;
            return ResearchTeamCopy;
        }
        public Team Group
        {
            get
            {
                Team group = new Team(this.nameorg, this.registnumb);
                return group;
            }
            set
            {
                nameorg = value.Nameorg;
                registnumb = value.Registnumb;
            }
        }
        public IEnumerable GetEnumeratornull()
        {
            for (int i = 0; i < personList.Count; i++)
            {
                bool t = false;
                for (int j = 0; j < paperList.Count; j++)
                {
                    if ((paperList[j] as Paper).Author.Equals((Person)personList[i]))
                    {
                        t = true;
                        break;
                    }
                }

                if (!t)
                    yield return personList[i];
            }
        }
        public IEnumerable<Paper> YearEnumerator(int Timeh)
        {
            Paper[] List = new Paper[paperList.Count];
            int k = 0;
            foreach (Paper i in paperList)
            {
                List[k] = i;
                k++;
            }
            int Yearrnow = DateTime.Now.Year - Timeh;
            for (int i = 0; i < paperList.Count; i++)
            {

                if (List[i].Date.Year > Yearrnow)
                    yield return List[i];
            }
        }
        public IEnumerable GetEnumeratorpubl()
        {
            for (int i = 0; i < personList.Count; i++)
            {
                int papcount = 0;
                for (int j = 0; j < PaperList.Count; j++)
                {
                    if ((paperList[j] as Paper).Author.Equals((Person)personList[i]))
                    {
                        papcount++;
                    }
                }

                if (papcount > 1)
                    yield return personList[i];
            }
        }
        public IEnumerable<Paper> LastPaper()
        {
            foreach (Paper i in paperList)
                if (i.Date.Year == DateTime.Now.Year)
                    yield return i;
        }
        public IEnumerator GetEnumerator()
        {
            return new ResearchTeamEnumerator(personList, paperList);
        }
        class ResearchTeamEnumerator : IEnumerator
        {
            private List<Person> persons;
            private List<Paper> papers;
            int position = -1;
            public ResearchTeamEnumerator(List<Person> persons_value, List<Paper> papers_value)
            {
                persons = persons_value;
                papers = papers_value;
            }
            public bool MoveNext()
            {
                position++;
                if (position < persons.Count - 1)
                {
                    bool t = false;
                    while (position < persons.Count)
                    {
                        for (int i = 0; i < papers.Count; i++)
                        {
                            if ((papers[i] as Paper).Author.Equals((Person)Current))
                            {
                                t = true;
                                break;
                            }
                        }

                        if (t)
                            break;
                        else
                            position++;
                    }

                    if (t)
                        return true;
                    else
                        return false;
                }
                else
                {
                    return false;
                }

            }
            public void Reset()
            {
                position = -1;
            }
            public object Current
            {
                get
                {
                    return persons[position];

                }
            }
        }
    }

}

