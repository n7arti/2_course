﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            Person per1 = new Person("Name4", "Surname1", new DateTime(1991, 1, 1));
            Person per2 = new Person("Name2", "Surname2", new DateTime(1992, 2, 2));
            Person per3 = new Person("Name3", "Surname3", new DateTime(1993, 3, 3));
            Person per4 = new Person("Name1", "Surname4", new DateTime(1994, 4, 4));
            Person per5 = new Person();

            Paper pap1 = new Paper();
            Paper pap2 = new Paper("topic5", per1, new DateTime(2011, 1, 1));
            Paper pap3 = new Paper("topic2", per4, new DateTime(2012, 2, 2));
            Paper pap4 = new Paper("topic4", per5, new DateTime(2013, 3, 3));
            Paper pap5 = new Paper("topic3", per2, new DateTime(2014, 4, 4));

            ResearchTeam RT1 = new ResearchTeam("RT1", "Org1", 111, TimeFrame.Year);
            RT1.AddMembers(per4, per1, per2, per3,per5);
            RT1.AddPaper(pap5, pap4, pap2, pap1, pap3);

            ResearchTeam RT2 = new ResearchTeam("RT2", "Org2", 222, TimeFrame.TwoYears);
            RT2.AddMembers(per1, per2, per3);
            RT2.AddPaper(pap5, pap4, pap3);

            ResearchTeam RT3 = new ResearchTeam("RT3", "Org3", 333, TimeFrame.Long);
            RT3.AddMembers(per4,per5);
            RT3.AddPaper(pap1, pap2, pap3);

            Console.WriteLine(".................. 1..................");//Выполнить сортировку 
            RT1.SortDate();
            Console.WriteLine(".......... По дате публикации.........");
            Console.WriteLine(RT1.ToString());
            RT1.SortName();
            Console.WriteLine("....... По названию публикации........");
            Console.WriteLine(RT1.ToString());
            RT1.SortAuthor();
            Console.WriteLine(".......... По фамилии автора..........");
            Console.WriteLine(RT1.ToString());

            Console.WriteLine(".................. 2..................");// Добавить в коллекцию несколько разных элементов
            KeySelector<string> XD = ResearchTeamCollections<string>.GenerateKey;
            ResearchTeamCollections<string> RTC1 = new ResearchTeamCollections<string>(XD);
            RTC1.AddResearchTeams(RT1, RT2, RT3);
            Console.WriteLine(RTC1.ToString());

            Console.WriteLine(".................. 3..................");
            //поиск даты последней по времени выхода публикации среди всех элементов коллекции
            Console.WriteLine("...... Дата последней публикации......");
            Console.WriteLine(RTC1.LastPubl);
            Console.WriteLine();
            //вызвать метод TimeFrameGroup для выбора объектов ResearchTeam с заданным значением продолжительности исследований;
            Console.WriteLine("  Продолжительность исследований(Year)");
            foreach (var i in RTC1.TimeFrameGroup(TimeFrame.Year))
                Console.WriteLine(i.ToString());
            Console.WriteLine();
            //вызвать свойство класса, выполняющее группировку элементов коллекции по значениию продолжительности исследований
            Console.WriteLine("Группировка элементов коллекции по значениию продолжительности исследований");
            Console.WriteLine();
            foreach (var i in RTC1.Group)
            {
                Console.WriteLine(i.Key);
                foreach (var j in i)
                    Console.WriteLine(j);
                Console.WriteLine();
            }
            Console.WriteLine(".................. 4..................");
            GenerateElement<Team, ResearchTeam> d = delegate (int i)
            {
                var key = new Team("Org6", i);
                var value = new ResearchTeam("topic6","Org6",i, (TimeFrame)(i % 3 + 1));
                return new KeyValuePair<Team, ResearchTeam>(key, value);
            };
            var TK = new TestCollections<Team, ResearchTeam>(d);
            Team n = new Team();
            TK.TimeContains(n);
            Console.WriteLine();
            TK.TimeContainsKey(n);
            Console.WriteLine();
            TK.TimeContainsValue();
        }
    }
}
