﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    delegate TKey KeySelector<TKey>(ResearchTeam rt);
    class ResearchTeamCollections<TKey>
    {
        private System.Collections.Generic.Dictionary<TKey, ResearchTeam> resTK;
        private KeySelector<TKey> xdel;
        public ResearchTeamCollections(KeySelector<TKey> xdel_value)
        {
            xdel = xdel_value;
            resTK = new Dictionary<TKey, ResearchTeam>();
        }
        public void AddDefaults()
        {
            ResearchTeam rt = new ResearchTeam();
            TKey key = xdel(rt);
            resTK.Add(key, rt);
        }
        public void AddResearchTeams(params ResearchTeam[] rt)
        {
            for(int i = 0; i < rt.Length; i++)
            {
                TKey key = xdel(rt[i]);
                resTK.Add(key, rt[i]);
            }
        }
        public override string ToString()
        {

            Dictionary<TKey, ResearchTeam>.ValueCollection collect = resTK.Values;
            string str = "";
            foreach (ResearchTeam i in collect)
            {
                str += i.ToString() + "\n\n";
            }
            return str;
        }
        public string ToShortString()
        {
            Dictionary<TKey, ResearchTeam>.ValueCollection collect = resTK.Values;
            string str = "";
            foreach (ResearchTeam i in collect)
            {
                str += i.ToShortString() + " " + i.PersonList.Count + " " + i.PaperList.Count + "\n\n";
            }
            return str;
        }
        public DateTime LastPubl
        {
            get
            {
                Dictionary<TKey, ResearchTeam>.ValueCollection collect = resTK.Values;
                if (collect.Count == 0)
                {
                    return new DateTime();
                }
                else
                {
                    List<Paper> PList = new List<Paper>();

                    foreach (ResearchTeam rt in collect)
                    {
                        PList.Add(rt.ReturnPublic);
                    }
                    return PList.Max(p => p.Date);
                }


            }
        }
        public IEnumerable<KeyValuePair<TKey, ResearchTeam>> TimeFrameGroup(TimeFrame value)
        {
            return resTK.Where(p => p.Value.Time == value);
        }
        public IEnumerable<IGrouping<TimeFrame, KeyValuePair<TKey, ResearchTeam>>> Group
        {
            get
            {
                return resTK.GroupBy(p=> p.Value.Time);
            }
        }
        public static string GenerateKey(ResearchTeam rt)
        {
            return rt.Group.ToString();
        }
    }
}
