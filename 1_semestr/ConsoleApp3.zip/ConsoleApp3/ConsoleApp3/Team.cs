﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3
{
    class Team: INameAndCopy
    {
        protected string nameorg;
        protected int registnumb;
        public Team(string nameorg_value, int registnumb_value)//конструктор с параметрами 
        {
            nameorg = nameorg_value;
            registnumb = registnumb_value;
        }
        public Team()//конструктор без параметров 
        {
            nameorg = "OAO App";
            registnumb = 123456;
        }
        public string Nameorg
        {
            get
            {
                return nameorg;
            }
            set
            {
                nameorg = value;
            }
        }
        public int Registnumb
        {
            get
            {
                return registnumb;
            }
            set
            {
                Exception e = new Exception("Ошибка! Введите число больше 0! ");
                try
                {
                    if (value <= 0)
                        throw e;
                    else
                        registnumb = value;
                }
                catch (Exception)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }
        string INameAndCopy.Name
        {
            get
            {
                return nameorg;
            }
            set
            {
                nameorg = value;
            }
        }
        public virtual object DeepCopy()
        {
            Team TeamCopy = new Team();
            TeamCopy.nameorg = this.nameorg;
            TeamCopy.registnumb = this.registnumb;
            return TeamCopy;
        }
        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            Team team1 = obj as Team;// возвращает null если объект нельзя привести к типу Team
            if (team1 as Team == null)
                return false;

            return (team1.nameorg == this.nameorg) && (team1.registnumb == this.registnumb);
        }

        public static bool operator ==(Team t1, Team t2)
        {
            if (object.ReferenceEquals(t1, null))
            {
                if (object.ReferenceEquals(t2, null))
                    return true;
                return false;
            }
            return t1.Equals(t2);
        }
        public static bool operator !=(Team t1, Team t2)
        {
            return !(t1 == t2);
        }

        public override int GetHashCode()
        {
            return nameorg.GetHashCode() + registnumb.GetHashCode();
        }
        public override string ToString()
        {
            return nameorg + " " + registnumb.ToString("d");
        }
    }
}
