﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp3
{
    enum TimeFrame { Year, TwoYears, Long };
}
